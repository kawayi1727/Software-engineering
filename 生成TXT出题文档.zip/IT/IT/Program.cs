﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IT
{
  public  class Program
    {
        static void Main(string[] args)
        {
            DataTable dt = new DataTable();
            Random number = new Random(); //实例化一个随机数           
            string[] operatos = new string[] { "＋", "－", "×", "÷" };
            string[] operatos1 = new string[] { "+", "-", "*", "/" };
            Console.WriteLine("要生成多少题，最多支持10000题");
            int draw = Convert.ToInt32(Console.ReadLine()); //获取出题量
            Console.WriteLine("要生多少以内的计算题(0~100之内)");
            int difficulty = Convert.ToInt32(Console.ReadLine()); //获取出题量  
                   //题目的TXT
                  //FileStream fs = new FileStream("D:\\四则运算题目.txt", FileMode.Create);
            string path = "D:\\四则运算题目.txt";
            //答案的TXT
            //FileStream da = new FileStream("D:\\四则运算的答案.txt", FileMode.Create);
            StreamWriter sw = new StreamWriter(path, false, Encoding.Default);
            sw.Flush();
            for (int s = 0; s < draw; s++)
            {
                int nubere_shu = number.Next(1, 4);
     var result= (Operation.formula(dt, number, difficulty, operatos, operatos1, nubere_shu));
                Console.WriteLine(result);
                #region 写入TXT

                //int plus = 1;
                //获得字节数组

                //fs.Flush();

                //开始写入
                sw.WriteLine(result);

                //清空缓冲区、关闭流
                //sw.Close();


                #endregion
            }
            sw.Close();

            // fs.Close();

            Console.ReadKey();
        }
    }
}